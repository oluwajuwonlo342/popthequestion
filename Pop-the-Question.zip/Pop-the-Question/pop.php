<?php
$conn = mysqli_connect("localhost", "root", "", "pop") or die("Error : " . mysqli_error($conn));

// $name = "";
// $sql = "SELECT Name FROM pop";
// $stmt = mysqli_query($conn, $sql);
// if (mysqli_num_rows($stmt) > 0) {
//     $row = mysqli_fetch_assoc($stmt);
//     $name = $row['Name'];
// }

if(isset($_POST["submit"])){
    $response = $_POST['user_response'];
    $sql = "insert into clicks (clicks) values('$response')";
    if(mysqli_query($conn, $sql)){
        echo "<script>alert('Success')</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="pop.css">
    <title>question</title>
</head>
<body>
    <div class="main">
        <h1>will you be my girlfriend?</h1>
        <form action="" method="post">
            <input type="radio" name="user_response" value="yes" required> Yes
            <input type="radio" name="user_response" value="no" required> No
            <button type="submit" name="submit">Submit</button>
        </form>
    </div>
</body>
</html>