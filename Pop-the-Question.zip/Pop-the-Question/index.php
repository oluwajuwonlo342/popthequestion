<?php

include('conn.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <!-- <link rel="stylesheet" href="pop.html"> -->
    <title>Pop the Question</title>
</head>
<body>
    <div class="section">
        <h1>Pop the Question</h1>
        <p>What's your name</p>
       <form action="" method="POST" enctype="multipart/form-data">
       <input type="text" id="name" name="name" required></input><br>
        <button type="submit" name="submit"> Enter </button>
       </form>
    </div>
</body>
</html>