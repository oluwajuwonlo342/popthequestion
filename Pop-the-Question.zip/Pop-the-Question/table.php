<?php
// Establish a connection to the database
$conn = mysqli_connect("localhost", "root", "", "pop");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to fetch data from both tables
$query = "SELECT c.clicks, p.Name 
           FROM clicks c 
           INNER JOIN pop p 
           ON c.id = p.id"; // Assuming there's a common column 'id' in both tables

$result = mysqli_query($conn, $query);

// Check if the query was successful
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

// Create a table to display the data
echo "<table>";
echo "<tr><th>Name</th><th>Clicks</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row["Name"] . "</td>";
    echo "<td>" . $row["clicks"] . "</td>";
   
    echo "</tr>";
}

echo "</table>";

// Close the connection
mysqli_close($conn);
?>
<style>
    table{
        border: 1px solid black;
        
    }
    th{
        border: 1px solid black;
        
    }
    tr{
        border: 1px solid black;

    }
</style>