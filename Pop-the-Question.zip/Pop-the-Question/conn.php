<?php
$conn = mysqli_connect("localhost","root", "", "pop") or die("Error : ".mysqli_error($conn));
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $insert = "insert into pop(Name) values ('$name')";
    if(mysqli_query($conn,$insert)){
        echo "<script>alert('okay')
        window.location.href='pop.php'</script>";
    }
    else{
        echo"<script>alert('failed')</script>";
    }
}
?>